# List of Contributors

* [Victor Penso](https://github.com/vpenso)
* [Matteo Dessalvi](https://github.com/mtds)

