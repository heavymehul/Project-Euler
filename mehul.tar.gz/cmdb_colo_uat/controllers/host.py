#!/usr/bin/python

from gluon.tools import Crud
crud = Crud(db)

from pymongo import MongoClient
client = MongoClient('mongodb://127.0.0.1:27017/mehuldb')
db = client.mehuldb
colls =  db.collection_names(include_system_collections=False)
cmdb_colo = db.cmdb_colo

def details():
    
    currentHostname = request.vars["hostname"]
    myrecord = cmdb_colo.find_one({"ansible_hostname": currentHostname})
    
    return myrecord
