#!/usr/bin/python

from gluon.tools import Crud
crud = Crud(db)

from pymongo import MongoClient
#client = MongoClient('mongodb://0.0.0.0,gbl12164,gbl12165:27017/')
client = MongoClient('mongodb://127.0.0.1:27017/mehuldb')
db = client.mehuldb
colls =  db.collection_names(include_system_collections=False)
nics = db.nics


def convert(input):

    # converts from unicode into normal

    if isinstance(input, dict):
        return dict((convert(key), convert(value)) for key, value in input.iteritems())
    elif isinstance(input, list):
        return [convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input

def colo():

    list = []
    newlist = []
    dict = {}
    currentHostname = request.vars["hostname"]
    myrecord = nics.find_one({"hostname": currentHostname})


    myrecord = convert(myrecord)
    list =  myrecord["interfaces"]

    for data in  list:
        newlist.append(data["NIC"] + " " + data["Status"] + " " + data["IpAddress"] + " " + data["Subnet"] + " " + data["MAC"] + " " + data["Speed"] + " " + data["Manufacturer"] + " " + data["Bonding Mode"] + " " + data["Active Bonding NIC"] + " " + data["Switch Port"] + " " + data["Switch Port Description"] + " " +data["Switch Name"] + " " + data["VLAN"])

    dict["hostname"] = newlist
    print dict

    response.view='colo_nic.html'

    return dict

