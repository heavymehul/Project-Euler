#!/usr/bin/python

import commands

from gluon.tools import Crud
crud = Crud(db)

from pymongo import MongoClient
client = MongoClient('mongodb://127.0.0.1:27017/mehuldb')
db = client.mehuldb
colls =  db.collection_names(include_system_collections=False)
cgroups = db.cgroups

def convert(input):

    # converts from unicode into normal

    if isinstance(input, dict):
        return dict((convert(key), convert(value)) for key, value in input.iteritems())
    elif isinstance(input, list):
        return [convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input



def details():
    
    currentHostname = request.vars["hostname"]
    myrecord = cgroups.find_one({"hostname": currentHostname})
    myrecord = convert(myrecord)
    
    #print myrecord
    response.view='colo_cgroups.html'


    return myrecord

def refresh():
    
    t = commands.getoutput("applications/cmdb_colo_uat/custom-scripts/refresh_cgroups_uat.sh") 
 
    return t

