from gluon.tools import Crud
crud = Crud(db)
response.cookies[response.session_id_name].secure=True
response.cookies[response.session_id_name].expires=360000
#response.cookies['session_id_cmdb]['expires'] = 24 * 3600

def index():


    cmdb_colo=db().select(db.cmdb_colo.ALL, orderby=db.cmdb_colo.ansible_hostname)

    return dict(cmdb_colo=cmdb_colo)
