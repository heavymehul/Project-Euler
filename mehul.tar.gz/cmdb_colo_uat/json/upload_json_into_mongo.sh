#!/bin/bash

/opt/eFX/apps/eriskuat/erisk-mongo_default_1/current/lib/mongoimport --db mehuldb --collection nics --type json --file /spare/web2py/applications/cmdb/json/nics_prd.json --jsonArray --host bb/gbl12165:27017,gbl12164:27017,0.0.0.0:27017
