#!/usr/bin/python

import json
import sys,os

prd_mw29west_filename = "/spare/web2py/applications/cmdb/json/puppet_status_mw29west_prd.json"
uat_mw29west_filename = "/spare/web2py/applications/cmdb/json/puppet_status_mw29west_uat.json"
prd_erisk_filename = "/spare/web2py/applications/cmdb/json/puppet_status_erisk_prd.json"
uat_erisk_filename = "/spare/web2py/applications/cmdb/json/puppet_status_erisk_uat.json"
prd_qlsi_filename = "/spare/web2py/applications/cmdb/json/puppet_status_qlsi_prd.json"
uat_qlsi_filename = "/spare/web2py/applications/cmdb/json/puppet_status_qlsi_uat.json"

prd_mw29west_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_mw29west_prd.csv"
uat_mw29west_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_mw29west_uat.csv"
prd_erisk_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_erisk_prd.csv"
uat_erisk_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_erisk_uat.csv"
prd_qlsi_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_qlsi_prd.csv"
uat_qlsi_outfile = "/spare/web2py/applications/cmdb/json/puppet_status_qlsi_uat.csv"


def convert(input):

    # converts from unicode into normal

    if isinstance(input, dict): return dict((convert(key), convert(value)) for key, value in input.iteritems())
    elif isinstance(input, list): return [convert(element) for element in input]
    elif isinstance(input, unicode): return input.encode('utf-8')
    else: return input

def json_to_csv(filename,outfile):

    with open(filename) as data_file: data = json.load(data_file)
    out = open(outfile, 'w')

    for server in data.keys(): 
        out.write(server + "," + data[server] + "\n")

    out.close()

if __name__ == '__main__':
    json_to_csv(prd_mw29west_filename,prd_mw29west_outfile)
    json_to_csv(uat_mw29west_filename,uat_mw29west_outfile)
    json_to_csv(prd_erisk_filename,prd_erisk_outfile)
    json_to_csv(uat_qlsi_filename,uat_qlsi_outfile)
    json_to_csv(prd_qlsi_filename,prd_qlsi_outfile)
    json_to_csv(uat_erisk_filename,uat_erisk_outfile)
