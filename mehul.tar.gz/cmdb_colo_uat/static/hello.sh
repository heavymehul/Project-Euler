#!/bin/bash

echo "Hello" > /spare/web2py/applications/cmdb_colo_uat/static/test
