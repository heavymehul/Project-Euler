#!/usr/bin/python

'''
Script to upload json data into mongo db collection
Creates a timestamp collection
Removes current cmdb collection
Copies fresh timestamp collection into new cmdb collection
'''

import datetime
import commands
import sys,os,os.path
sys.path.append('/spare/web2py')
from pymongo import MongoClient

date_ext =  datetime.datetime.now().strftime("%d%m%Y") 

# Create Mongo connections 
#client = client = MongoClient("mongodb://0.0.0.0:27018")
client = client = MongoClient("mongodb://127.0.0.1:27017")
db = client.mehuldb

# load json data into the timestamp collection

#load_uat = commands.getoutput("/opt/eFX/apps/eriskuat/erisk-mongo_default_2/current/lib/mongoimport --db mehuldb --collection cmdb" + date_ext + " --type json --file /opt/eFX/apps/eriskuat/erisk-dashboard/scripts/erisk/data/cmdb_facter_generated_uat.json --jsonArray --port 27018")
#load_prd = commands.getoutput("/opt/eFX/apps/eriskuat/erisk-mongo_default_2/current/lib/mongoimport --db mehuldb --collection cmdb" + date_ext + " --type json --file /opt/eFX/apps/eriskuat/erisk-dashboard/scripts/erisk/data/cmdb_facter_generated_prd.json --jsonArray --port 27018")

coll = "cmdb" + date_ext

# Remove any null hostname entries
#db[coll].remove( {'hostname': {'$exists': 'false'} } )

# Remove the cmdb collection
db.cmdb.remove()


# Copy the cmdb_date collection to cmdb
copy_date_collection = commands.getoutput("/spare/mongodb/bin/mongoexport --db mehuldb --c  cmdb" + date_ext + " --host 127.0.0.1:27017 | /spare/mongodb/bin/mongoimport --db mehuldb --collection cmdb --drop --host 127.0.0.1:27017")

# Export the data from the cmdb datestamp collection
collection = db[coll].find()

# Import the data from the cmdb datestamp collection
for document in collection: db.cmdb3.insert_one(document)
