#!/bin/bash

su - 43950953 -c "/home/43950953/cmdb/copy_cgroups_locally.sh"
sleep 5
/spare/web2py/applications/cmdb_colo_uat/custom-scripts/upload_cgroups_in_mongo.sh
