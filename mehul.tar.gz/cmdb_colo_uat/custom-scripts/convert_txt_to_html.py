#!/usr/bin/python

import os

for file in os.listdir("/spare/web2py/applications/cmdb_colo_uat/static/fqc"):
    if file.endswith(".txt"):
        hostname =  file[:14]

        input_file = open("/spare/web2py/applications/cmdb_colo_uat/static/fqc/" +file , 'r')
        text = input_file.read()
        input_file.close()

        outfile = open("/spare/web2py/applications/cmdb_colo_uat/static/fqc/" + hostname+ "_fqc.html", 'w')
        outfile.write("<html>")
        outfile.write('<header><title>CMDB Config Drift for ' +hostname+ ' </title></header>')
        outfile.write("<body>")

        outfile.write('<p><font size="24" color="blue">Configuration Drift Report for ' +hostname+ '</font></p>')

        for line in text.split("\n"):  
            if "PASS:" in line: outfile.writelines('<p><font color="green">' +line+ '</font></p>')
            elif "FAIL" in line: outfile.writelines('<p><font color="red">' +line+ '</font></p>')

        outfile.write("</body>")
        outfile.write("</html>")
