#!/usr/bin/python

import commands
import json
import pycurl
import urllib

class Test:
   def __init__(self):
       self.contents = ''

   def body_callback(self, buf):
       self.contents = self.contents + buf

def convert(input):

    # converts from unicode into normal

    if isinstance(input, dict): return dict((convert(key), convert(value)) for key, value in input.iteritems())
    elif isinstance(input, list): return [convert(element) for element in input]
    elif isinstance(input, unicode): return input.encode('utf-8')
    else: return input

def prod_list():
    t = Test()

    c = pycurl.Curl()
    params = {'q': 'SHOW TAG VALUES FROM cpu WITH KEY = "host"'}

    c.setopt(c.URL, 'http://gbl05676.systems.uk.hsbc:12086/query?db=efx&u=admin&p=HSBC1234&' + urllib.urlencode(params))
    c.setopt(c.WRITEFUNCTION, t.body_callback)

    c.perform()
    c.close()

    data = json.loads(t.contents)

    output = convert(data)
    prod_list = []
    for value in output["results"][0]["series"][0]["values"]: prod_list.append(value[1])

    return prod_list



def create_list():
    t = Test()

    c = pycurl.Curl()
    params = {'q': 'SHOW TAG VALUES FROM cpu WITH KEY = "host"'}

    c.setopt(c.URL, 'http://gbl05673.systems.uk.hsbc:12086/query?db=efx&u=root&p=root&' + urllib.urlencode(params))
    c.setopt(c.WRITEFUNCTION, t.body_callback)

    c.perform() 
    c.close()

    data = json.loads(t.contents)

    output = convert(data)

    prod_list()
    prod =  prod_list()

    uat_list = []
    for value in output["results"][0]["series"][0]["values"]: 
        # do not reference prod hosts that are initially set in UAT to this list
        if value[1] not in prod: uat_list.append(value[1])


    print uat_list



if __name__ == '__main__':
    create_list()
