#!/usr/bin/python

'''
Removes current cmdb collection
Uploads new cmdb data into cmdb collection
'''

import datetime
import commands
import sys,os,os.path
sys.path.append('/spare/web2py')
from pymongo import MongoClient


# Create Mongo connections 
#client = client = MongoClient("mongodb://0.0.0.0:27018")
client = client = MongoClient("mongodb://127.0.0.1:27017")
db = client.mehuldb

# load json data into the timestamp collection

# Remove the cmdb collection
db.cgroups.drop()

# Upload new json data

load_cgroups = commands.getoutput("/spare/mongodb/bin/mongoimport --db mehuldb --collection cgroups --type json --file /spare/web2py/applications/cmdb_colo_uat/json/cgroups_cmdb_colo_uat.json --jsonArray --host 127.0.0.1:27017")
