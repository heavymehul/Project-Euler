#!/usr/bin/python

'''
Removes current cmdb collection
Uploads new cmdb data into cmdb collection
'''

import datetime
import commands
import sys,os,os.path
sys.path.append('/spare/web2py')
from pymongo import MongoClient


# Create Mongo connections 
#client = client = MongoClient("mongodb://0.0.0.0:27018")
client = client = MongoClient("mongodb://127.0.0.1:27017")
db = client.mehuldb

# load json data into the timestamp collection

# Remove the cmdb collection
db.cmdb_colo.drop()

# Upload new json data

load_data = commands.getoutput("/spare/mongodb/bin/mongoimport --db mehuldb --collection cmdb_colo --type json --file /spare/web2py/applications/cmdb_colo_uat/json/cmdb_colo_uat.json --jsonArray --host 127.0.0.1:27017")

# remove null hostname entries
#db.cmdb.delete_one({"hostname":{"$exists":"false"}})

db.cmdb.delete_many( {"hostname":{"$exists":False}})
